globalThis.inspectGeminiStatus=()=>{
 const visible=e=>!!e&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
 const editors=[...document.querySelectorAll('rich-textarea [contenteditable="true"],.ql-editor[contenteditable="true"],[role="textbox"][contenteditable="true"],textarea')].filter(visible);
 const editor=editors.find(e=>e.closest('rich-textarea'))||editors.find(e=>/Gemini|输入提示|输入问题|Enter a prompt/i.test([e.getAttribute('aria-label'),e.getAttribute('placeholder'),e.getAttribute('data-placeholder')].join(' ')));
 const bounds=editor?.getBoundingClientRect();
 const nearby=[...document.querySelectorAll('button,[role="button"]')].filter(visible).filter(b=>{if(!bounds)return false;const r=b.getBoundingClientRect();return Math.abs((r.top+r.bottom)/2-(bounds.top+bounds.bottom)/2)<150&&r.left>=bounds.left-100&&r.left<bounds.right+180;});
 const label=b=>[b.getAttribute('aria-label'),b.getAttribute('title'),b.getAttribute('data-test-id'),b.getAttribute('data-testid')].filter(Boolean).join(' ');
 const stop=nearby.some(b=>/stop[- ]?(response|generating|generation)|停止(回答|回复|生成|响应)|中止(生成|回复)/i.test(label(b))||b.matches('.stop-button,[data-test-id="stop-button"]'));
 const iconStop=nearby.some(b=>[...b.querySelectorAll('mat-icon')].some(i=>/^stop(_circle)?$/.test((i.textContent||'').trim())));
 const idle=!!editor&&nearby.some(b=>/send[- ]?(message|button)|发送|提交|microphone|麦克风|使用麦克风|语音输入/i.test(label(b)));
 return {status:stop||iconStop?'working':idle?'idle':'unknown',reason:stop?'stop-label':iconStop?'composer-stop-icon':idle?'composer-idle':'unrecognized',editorFound:!!editor,buttons:nearby.map(b=>({label:b.getAttribute('aria-label'),testId:b.getAttribute('data-test-id'),title:b.getAttribute('title'),icons:[...b.querySelectorAll('mat-icon')].map(i=>i.getAttribute('fonticon')||i.getAttribute('data-mat-icon-name')||(/^[a-z_]{1,40}$/.test((i.textContent||'').trim())?i.textContent.trim():''))}))};
};
globalThis.detectGeminiStatus=()=>inspectGeminiStatus().status;
