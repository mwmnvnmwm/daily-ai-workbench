// Shared by the two browser extensions. Only explicitly enabled devices may claim work.
{
 const provider=chrome.runtime.getManifest().host_permissions.some(p=>p.startsWith('https://chatgpt.com/'))?'chatgpt-browser':'gemini-browser';
 const origin=provider==='chatgpt-browser'?'https://chatgpt.com':'https://gemini.google.com';
 const endpoint='https://boihsaschmgzfgjxhjvk.supabase.co/rest/v1/rpc/';
 let chain=Promise.resolve(),pumping=false;
 const locked=fn=>{const result=chain.then(fn,fn);chain=result.catch(()=>{});return result;};
 const safeUrl=url=>typeof url==='string'&&(provider==='chatgpt-browser'?/^https:\/\/chatgpt\.com\/c\/[\w-]+$/:/^https:\/\/gemini\.google\.com\/app\/[\w-]+$/).test(url);
 async function rpc(config,name,body){
  const response=await fetch(endpoint+name,{method:'POST',headers:{apikey:config.publicKey,'Content-Type':'application/json'},body:JSON.stringify({p_token:config.token,...body}),signal:AbortSignal.timeout(10000)});
  const data=await response.json();
  if(!response.ok){const error=Error('讨论室连接失败');error.revoked=response.status===401||response.status===403||data?.message==='Invalid credential';throw error;}
  return data;
 }
 async function flush(active,config){
  const accepted=await rpc(config,'report_discussion_delivery',{p_id:active.job.id,p_lease:active.job.lease,p_sequence:active.sequence,p_status:active.status,p_answer:active.answer||'',p_url:safeUrl(active.url)?active.url:null,p_error:active.error||''});
  if(accepted===false||['completed','failed'].includes(active.status)){
   await chrome.storage.local.remove('discussionActive');
   try{await chrome.tabs.sendMessage(active.tabId,{type:'discussion-stop',id:active.job.id});}catch{}
   return false;
  }
  return true;
 }
 async function drive(active){
  try{await chrome.tabs.sendMessage(active.tabId,{type:'discussion-start',task:{...active.job,expectedUrl:active.url,resume:!!active.intent,baseline:active.baseline}});}catch{}
 }
 async function pump(){
  if(pumping)return;pumping=true;
  try{await locked(async()=>{
   const {config,discussionActive,discussionTabs={}}=await chrome.storage.local.get(['config','discussionActive','discussionTabs']);
   if(!config||config.provider!==provider)return;
   if(discussionActive){
    // Retry persisted progress after an offline period before accepting another job.
    try{if(!await flush(discussionActive,config))return;}catch(error){
     if(error.revoked){await chrome.storage.local.remove('discussionActive');try{await chrome.tabs.sendMessage(discussionActive.tabId,{type:'discussion-stop',id:discussionActive.job.id});}catch{}}
     return;
    }
    try{await chrome.tabs.get(discussionActive.tabId);await drive(discussionActive);}
    catch{
     discussionActive.sequence++;discussionActive.status='failed';discussionActive.error='讨论标签页已关闭；请检查原聊天。';
     await chrome.storage.local.set({discussionActive});await flush(discussionActive,config);
    }
    return;
   }
   const job=await rpc(config,'claim_discussion_delivery',{});if(!job)return;
   const active={job,sequence:1,status:'claimed',answer:'',intent:false,tabId:null,url:job.chatUrl||null};
   await chrome.storage.local.set({discussionActive:active});
   try{
    let tab;
    if(job.chatUrl&&safeUrl(job.chatUrl)&&discussionTabs[job.room]){
     try{const candidate=await chrome.tabs.get(discussionTabs[job.room]);if(candidate.url===job.chatUrl)tab=candidate;}catch{}
    }
    if(job.chatUrl&&!safeUrl(job.chatUrl))throw Error('原聊天地址无效');
    if(!tab)tab=await chrome.tabs.create({url:job.chatUrl||origin+(provider==='gemini-browser'?'/app':'/'),active:false});
    active.tabId=tab.id;discussionTabs[job.room]=tab.id;
    await chrome.storage.local.set({discussionActive:active,discussionTabs});await drive(active);
   }catch{
    active.sequence++;active.status='failed';active.error='无法打开原应用，请检查扩展权限和登录状态。';
    await chrome.storage.local.set({discussionActive:active});await flush(active,config);
   }
  });}catch{}finally{pumping=false;}
 }
 chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message.type==='discussion-ready'){
   if(sender.tab&&sender.url?.startsWith(origin+'/'))pump();return;
  }
  if(!['discussion-prepare','discussion-progress'].includes(message.type))return;
  if(!sender.tab||!sender.url?.startsWith(origin+'/'))return;
  locked(async()=>{
   const {config,discussionActive:active}=await chrome.storage.local.get(['config','discussionActive']);
   if(!config||!active||active.tabId!==sender.tab.id||active.job.id!==message.id)return {ok:false,stop:true};
   if(message.type==='discussion-prepare'){
    if(active.intent)return {ok:false,stop:true};
    active.intent=true;active.baseline=message.baseline;active.status='sent';
   }else{
    if(!['claimed','sent','streaming','completed','failed'].includes(message.status)||typeof message.answer!=='string'||message.answer.length>200000)return {ok:false};
    if(active.intent&&message.status==='claimed')return {ok:false};
    if(active.status==='streaming'&&message.status==='sent')return {ok:false};
    active.status=message.status;active.answer=message.answer;active.error=String(message.error||'').slice(0,1000);
   }
   if(message.url&&safeUrl(message.url))active.url=message.url;
   active.sequence++;
   await chrome.storage.local.set({discussionActive:active});
   try{const keep=await flush(active,config);return {ok:true,stop:!keep};}catch{return {ok:false,offline:true};}
  }).then(reply,()=>reply({ok:false}));return true;
 });
 chrome.tabs.onUpdated.addListener((id,change)=>{if(change.status==='complete')pump();});
 chrome.tabs.onRemoved.addListener(()=>pump());
 chrome.alarms.create('discussion-poll',{periodInMinutes:0.5});
 chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='discussion-poll')pump();});
 setInterval(pump,5000);pump();
}
