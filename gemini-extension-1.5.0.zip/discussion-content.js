// Reads only the dedicated conversation currently assigned by the extension worker.
globalThis.stopWorkbenchDiscussion?.();
{
 const chatgpt=location.hostname==='chatgpt.com';
 let task=null,running=false,stopped=false,heartbeat;
 const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 const normalize=text=>String(text||'').replace(/\s+/g,' ').trim();
 const editor=()=>chatgpt?globalThis.findChatGPTEditor?.():globalThis.findGeminiEditor?.();
 const status=()=>chatgpt?globalThis.detectChatGPTStatus?.():globalThis.detectGeminiStatus?.();
 const visible=e=>e&&e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden';
 const inputText=e=>e?(e.tagName==='TEXTAREA'?e.value:e.innerText||e.textContent||''):'';
 const users=()=>[...document.querySelectorAll(chatgpt?'[data-message-author-role="user"]':'user-query')];
 const answers=()=>[...document.querySelectorAll(chatgpt?'[data-message-author-role="assistant"]':'model-response')];
 const answerText=e=>e?(chatgpt?e.innerText:(e.querySelector('message-content,.model-response-text,.markdown')||e).innerText):'';
 const chatUrl=()=>{
  const match=location.pathname.match(chatgpt?/^\/c\/[\w-]+$/:/^\/app\/[\w-]+$/);
  return match?location.origin+match[0]:null;
 };
 const send=(type,extra={})=>chrome.runtime.sendMessage({type,id:task?.id,...extra});
 async function progress(state,answer='',error=''){
  if(stopped)return;
  const result=await send('discussion-progress',{status:state,answer:answer.slice(0,200000),url:chatUrl(),error});
  if(result?.stop)stopped=true;
  return result;
 }
 function sendButton(){
  const bounds=editor()?.getBoundingClientRect();
  return [...document.querySelectorAll('button,[role="button"]')].filter(visible).find(b=>{
   const r=b.getBoundingClientRect();
   if(!bounds||Math.abs((r.top+r.bottom)/2-(bounds.top+bounds.bottom)/2)>150||r.left<bounds.left-100||r.left>bounds.right+180)return false;
   const label=[b.getAttribute('aria-label'),b.getAttribute('title'),b.getAttribute('data-testid'),b.getAttribute('data-test-id')].join(' ');
   return !b.disabled&&b.getAttribute('aria-disabled')!=='true'&&(/send[- ]?(button|message|prompt)|发送|提交/i.test(label)||(chatgpt?false:b.matches('.send-button')));
  });
 }
 async function run(assignment){
  if(running||stopped)return;running=true;task=assignment;let lastAnswer='',lastPublished=0,changed=Date.now();
  const message=assignment.chatUrl?assignment.message:`讨论主题：${assignment.title}\n\n${assignment.message}`;
  let baseline=assignment.baseline,boundUrl=assignment.expectedUrl||assignment.chatUrl||null;
  try{
   // A follow-up must land on its exact original conversation.
   if(boundUrl&&chatUrl()!==boundUrl)throw Error('当前页面与讨论室原聊天不一致，已停止发送。');
   if(!assignment.resume){
    const started=Date.now();let box;
    while(!stopped&&Date.now()-started<45000){box=editor();if(box&&status()!=='working')break;await progress('claimed');await pause(1500);}
    if(stopped)return;
    if(!box)throw Error('未找到聊天输入框，请登录原应用并刷新扩展。');
    if(status()==='working'||normalize(inputText(box)))throw Error('原聊天正在生成或存在未发送草稿，请处理后重新发起。');
    if(!assignment.chatUrl&&users().length)throw Error('新聊天页面包含已有对话，已停止发送。');
    box.focus();
    if(box.tagName==='TEXTAREA'){
     Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(box,message);
     box.dispatchEvent(new Event('input',{bubbles:true}));
    }else{
     if(!document.execCommand('insertText',false,message))throw Error('无法写入输入框，请检查原应用。');
     box.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:message}));
    }
    let button;const wait=Date.now();
    while(!stopped&&Date.now()-wait<10000){button=sendButton();if(button)break;await pause(300);}
    if(!button)throw Error('发送按钮不可用，消息保留在原应用草稿中。');
    baseline={users:users().length,answers:answers().length,previousAnswer:answerText(answers().at(-1))};
    // Persist intent and acknowledge to the server before the one and only click.
    const prepared=await send('discussion-prepare',{baseline,url:chatUrl()});
    if(!prepared?.ok||prepared.stop)throw Error('未能确认发送权限，已停止；请检查原应用草稿。');
    button.click();
   }
   const began=Date.now();let matched=false;
   while(!stopped&&Date.now()-began<15*60*1000){
    const url=chatUrl();if(url){if(boundUrl&&url!==boundUrl)throw Error('页面已切换到其他聊天，已停止同步。');boundUrl=url;}
    const user=users().at(-1),answer=answers().at(-1);
    matched=normalize(inputText(chatgpt?user:user?.querySelector('.query-text')||user))===normalize(message);
    const fresh=!baseline||users().length>baseline.users||answerText(answer)!==baseline.previousAnswer;
    const paired=matched&&fresh&&answer&&!!(user.compareDocumentPosition(answer)&Node.DOCUMENT_POSITION_FOLLOWING);
    const text=paired?answerText(answer).trim():'';
    if(text&&text!==lastAnswer){lastAnswer=text;changed=Date.now();}
    const complete=text&&chatUrl()&&status()==='idle'&&Date.now()-changed>=3000;
    if(complete){await progress('completed',text);return;}
    if(Date.now()-lastPublished>10000||(text&&Date.now()-changed<1200)){
     await progress(lastAnswer?'streaming':'sent',lastAnswer);lastPublished=Date.now();
    }
    if(!matched&&Date.now()-began>45000)throw Error('未确认消息已进入原聊天，已停止等待；请检查原应用，系统不会自动重发。');
    await pause(1000);
   }
   if(!stopped)await progress('failed',lastAnswer,'等待回答超时；原应用可能仍在生成，请打开原聊天查看。');
  }catch(error){try{await progress('failed',lastAnswer,String(error.message||error));}catch{}}
  finally{running=false;}
 }
 const listener=(message,sender,reply)=>{
  if(message.type==='discussion-start'){
   if(task&&task.id!==message.task.id){task=null;stopped=false;}
   if(!running){stopped=false;run(message.task);}reply({ok:true});
  }
  if(message.type==='discussion-stop'&&message.id===task?.id){stopped=true;reply({ok:true});}
 };
 chrome.runtime.onMessage.addListener(listener);
 const ready=()=>{try{Promise.resolve(chrome.runtime.sendMessage({type:'discussion-ready'})).catch(()=>{});}catch{}};
 heartbeat=setInterval(ready,5000);ready();
 globalThis.stopWorkbenchDiscussion=()=>{stopped=true;clearInterval(heartbeat);chrome.runtime.onMessage.removeListener(listener);};
}
