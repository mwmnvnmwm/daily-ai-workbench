let last='',sent=0,timer,interval,stopped=false;
function stop(){stopped=true;observer.disconnect();clearTimeout(timer);clearInterval(interval);}
function failed(error){if(/context invalidated/i.test(String(error))||!chrome.runtime?.id)stop();}
function report(){
 if(stopped)return;
 try{
  if(!chrome.runtime?.id){stop();return;}
  const status=detectChatGPTStatus();if(status===last&&Date.now()-sent<15000)return;
  last=status;sent=Date.now();
  Promise.resolve(chrome.runtime.sendMessage({type:'status',status})).catch(failed);
 }catch(error){failed(error);}
}
const observer=new MutationObserver(()=>{if(stopped||timer)return;timer=setTimeout(()=>{timer=null;report();},250);});
observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['disabled','aria-label','data-testid','style','class']});
interval=setInterval(report,15000);
try{chrome.runtime.onMessage.addListener((m,s,reply)=>{if(stopped)return;if(m.type==='probe')reply({status:detectChatGPTStatus()});if(m.type==='diagnose')reply(inspectChatGPTStatus());});}catch(error){failed(error);}
report();
