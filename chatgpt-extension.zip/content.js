let last='',sent=0;
function report(){const status=detectChatGPTStatus();if(status===last&&Date.now()-sent<15000)return;last=status;sent=Date.now();chrome.runtime.sendMessage({type:'status',status}).catch(()=>{});}
let timer;new MutationObserver(()=>{if(timer)return;timer=setTimeout(()=>{timer=null;report();},250);}).observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['disabled','aria-label','data-testid','style','class']});
setInterval(report,15000);report();
chrome.runtime.onMessage.addListener((m,s,reply)=>{if(m.type==='probe')reply({status:detectChatGPTStatus()});});
chrome.runtime.onMessage.addListener((m,s,reply)=>{if(m.type==='diagnose')reply(inspectChatGPTStatus());});
