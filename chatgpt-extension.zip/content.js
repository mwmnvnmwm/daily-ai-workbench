let last='',sent=0;
function report(){const status=detectChatGPTStatus();if(status===last&&Date.now()-sent<15000)return;last=status;sent=Date.now();chrome.runtime.sendMessage({type:'status',status}).catch(()=>{});}
let timer;new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(report,250);}).observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['disabled','aria-label','data-testid','style','class']});
setInterval(report,15000);report();
chrome.runtime.onMessage.addListener((m,s,reply)=>{if(m.type==='probe')reply({status:detectChatGPTStatus()});});
