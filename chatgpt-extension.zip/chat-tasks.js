// Observe an explicit send action; never serialize the prompt or response body.
globalThis.stopWorkbenchChatTasks?.();
(()=>{
 const provider=location.hostname==='chatgpt.com'?'chatgpt-browser':'gemini-browser';
 let pending=null,disposed=false,inflight=false,reason="waiting-for-send";
 const userCount=()=>document.querySelectorAll('[data-message-author-role="user"],user-query').length;
 const detect=()=>provider==='chatgpt-browser'?detectChatGPTStatus():detectGeminiStatus();
 const editor=()=>document.querySelector('#prompt-textarea,rich-textarea [contenteditable="true"],textarea[placeholder],.ql-editor[contenteditable="true"]');
 function intent(){const e=editor();if(!e||(e.value??e.textContent??'').trim()==='')return;pending={at:Date.now(),event:crypto.randomUUID(),confirmed:0,path:location.pathname,userCount:userCount()};reason='send-observed';}
 function key(e){if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&editor()?.contains(e.target))intent();}
 function click(e){const b=e.target.closest('button');if(!b)return;const label=[b.getAttribute('aria-label'),b.getAttribute('data-testid'),b.getAttribute('title')].filter(Boolean).join(' ');if(/^(send|发送|提交)|send-button|send message|发送消息|发送提示/i.test(label))intent();}
 document.addEventListener('keydown',key,true);document.addEventListener('click',click,true);
 const timer=setInterval(()=>{
  if(disposed||!pending||inflight)return;
  if(Date.now()-pending.at>120000){reason="send-expired";pending=null;return;}
  try{
   if(!pending.confirmed&&(detect()==='working'||(userCount()>pending.userCount&&(editor()?.value??editor()?.textContent??'').trim()===''))){pending.confirmed=Date.now();reason='send-confirmed';}
   if(!pending.confirmed||Date.now()-pending.confirmed<4000)return;
   const match=location.pathname.match(provider==='chatgpt-browser'?/\/c\/([^/]+)/:/\/app\/([^/]+)/);if(!match){reason='waiting-for-chat-id';return;}
   const same=[...document.querySelectorAll('a[href]')].find(a=>{try{return new URL(a.href).pathname===location.pathname;}catch{return false;}});
   const selected=document.querySelector('.conversation.selected .conversation-title,.conversation-container.selected .conversation-title');
   let title=(same?.textContent||selected?.textContent||document.title).trim().replace(/\s*[-–|]\s*(ChatGPT|Google Gemini|Gemini)\s*$/i,'').slice(0,300);
   if(!title||/^(ChatGPT|Gemini|Google Gemini|新对话|New chat)$/i.test(title)){reason='waiting-for-title';return;}
   const group=location.pathname.match(/\/g\/(g-p-[^/]+)/)?.[1];
   const groupLink=group?[...document.querySelectorAll('a[href]')].find(a=>a.href.includes('/g/'+group)&&!a.href.includes('/c/')):null;
   const source=group?'project:'+group:'chat:'+match[1];
   const sourceLabel=(groupLink?.textContent?.trim()||title).slice(0,300);
   const event={type:'chat-task',session:match[1],event:pending.event,title,source,sourceLabel,at:pending.at};
   inflight=true;reason='uploading';chrome.runtime.sendMessage(event).then(reply=>{if(reply?.ok){pending=null;reason='queued';}else reason='worker-not-acknowledged';}).catch(()=>{reason='worker-unavailable';}).finally(()=>{inflight=false;});
  }catch{}
 },500);
 globalThis.workbenchChatTaskDiagnostic=()=>({version:'1.1.1',reason,pending:!!pending,confirmed:!!pending?.confirmed,editorFound:!!editor(),userMessageCount:userCount()});
 globalThis.stopWorkbenchChatTasks=()=>{disposed=true;clearInterval(timer);document.removeEventListener('keydown',key,true);document.removeEventListener('click',click,true);};
})();
