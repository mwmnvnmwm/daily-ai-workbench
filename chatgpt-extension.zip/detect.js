globalThis.findChatGPTEditor=()=>{
 const visible=e=>!!e&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
 const editors=[...document.querySelectorAll('#prompt-textarea,[contenteditable="true"][role="textbox"],textarea[placeholder]')].filter(visible);
 return editors.find(e=>e.id==='prompt-textarea')||editors.find(e=>/ChatGPT|询问|Ask/i.test(e.getAttribute('placeholder')||e.getAttribute('aria-label')||''));
};
globalThis.inspectChatGPTStatus=()=>{
 const visible=e=>!!e&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
 const buttons=[...document.querySelectorAll('button,[role="button"]')].filter(visible);
 const editor=findChatGPTEditor();
 const bounds=editor?.getBoundingClientRect();
 // Limit icon-only fallback to the action buttons beside the composer, never answer content.
 const nearby=buttons.filter(b=>{if(!bounds)return false;const r=b.getBoundingClientRect();return Math.abs((r.top+r.bottom)/2-(bounds.top+bounds.bottom)/2)<70&&r.left>=bounds.left&&r.left<bounds.right+160;});
 const label=b=>[b.getAttribute('aria-label'),b.getAttribute('title'),b.getAttribute('data-testid'),b.getAttribute('data-state')].filter(Boolean).join(' ');
 const stop=buttons.some(b=>/\bstop[- ]?(button|streaming|generating|generation|response|responding)\b/i.test(label(b))||/停止(生成|响应|回答|回复|输出|流式传输)/.test(label(b)))||nearby.some(b=>/^(stop\b|停止)/i.test(label(b)));
 const square=nearby.some(b=>[...b.querySelectorAll('svg rect')].some(rect=>{
  const svg=rect.closest('svg'),v=svg.viewBox.baseVal,w=Number(rect.getAttribute('width')),h=Number(rect.getAttribute('height'));
  return v.width>0&&w>=v.width*.3&&w<=v.width*.8&&Math.abs(w-h)<.5&&rect.getAttribute('fill')!=='none'&&getComputedStyle(rect).fill!=='none';
 }));
 const namedIcon=nearby.some(b=>b.querySelector('svg use[href*="stop"],svg use[href*="square"],[data-icon="stop"],[data-icon="square"]'));
 const idle=!!editor&&buttons.some(b=>/send[- ]?(button|prompt|message)|发送|start voice|voice mode|语音模式/i.test(label(b)));
 const status=stop||square||namedIcon?'working':idle?'idle':'unknown';
 // Diagnostic metadata only: no body text, editor values, conversation URL, cookies or tokens.
 return {status,reason:stop?'stop-label':square?'composer-square':namedIcon?'composer-stop-icon':idle?'composer-idle':'unrecognized',editorFound:!!editor,buttons:nearby.map(b=>({label:b.getAttribute('aria-label'),testId:b.getAttribute('data-testid'),title:b.getAttribute('title'),rects:b.querySelectorAll('svg rect').length,uses:[...b.querySelectorAll('svg use')].map(u=>u.getAttribute('href')),paths:[...b.querySelectorAll('svg path')].map(p=>p.getAttribute('d'))}))};
};
globalThis.detectChatGPTStatus=()=>inspectChatGPTStatus().status;
