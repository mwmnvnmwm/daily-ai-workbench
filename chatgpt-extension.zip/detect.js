globalThis.detectChatGPTStatus=()=>{
 const visible=e=>!!e&&e.getClientRects().length>0;
 const stop=[...document.querySelectorAll('button[data-testid="stop-button"],button[aria-label="Stop streaming"],button[aria-label="Stop generating"],button[aria-label="停止生成"]')].some(visible);
 if(stop)return 'working';
 const editor=document.querySelector('#prompt-textarea');
 const send=document.querySelector('button[data-testid="send-button"],button[aria-label="Send prompt"],button[aria-label="发送提示"]');
 return visible(editor)&&visible(send)?'idle':'unknown';
};
