const status=document.getElementById('status');
document.getElementById('diagnose').onclick=async()=>{
 const output=document.getElementById('diagnostic');output.hidden=false;
 try{const tabs=await chrome.tabs.query({active:true,currentWindow:true});const tab=tabs[0];if(!tab?.url?.startsWith('https://gemini.google.com/')){output.value='请在 Gemini 网页上打开扩展。';return;}
 let result;
 try{result=await chrome.tabs.sendMessage(tab.id,{type:'diagnose'});}catch{}
 if(!result){
  await chrome.scripting.executeScript({target:{tabId:tab.id},files:['detect.js','content.js']});
  result=await chrome.tabs.sendMessage(tab.id,{type:'diagnose'});
 }
 output.value=JSON.stringify({version:chrome.runtime.getManifest().version,...result},null,2);
 }catch(error){output.value='页面连接失败：'+String(error?.message||error)+'\n请确认扩展的网站访问权限允许 gemini.google.com，再刷新页面。';}
};
document.getElementById('bind').onclick=async()=>{try{const config=JSON.parse(decodeURIComponent(atob(document.getElementById('code').value.trim())));const r=await chrome.runtime.sendMessage({type:'bind',config});if(!r?.ok)throw Error();document.getElementById('code').value='';status.textContent='已保存绑定，请刷新 Gemini 网页。';}catch{status.textContent='绑定失败，请检查配网码。';}};
document.getElementById('clear').onclick=async()=>{await chrome.storage.local.remove(['config','states','last']);status.textContent='已停止上报。请在工作台移除该设备，以立即撤销凭据。';};
const labels={working:'正在生成',idle:'空闲',unknown:'界面状态无法确认',offline:'没有打开 Gemini 网页'};
chrome.storage.local.get(['config','last']).then(({config,last})=>{status.textContent=!config?'尚未绑定':last?`${last.ok?'已上报':'上报失败'}：${labels[last.status]} · ${new Date(last.at).toLocaleTimeString()}`:'等待上报';});
