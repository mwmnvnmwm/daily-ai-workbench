const URL_BASE='https://boihsaschmgzfgjxhjvk.supabase.co';
chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
let serial=Promise.resolve();
function queue(fn){serial=serial.then(fn,fn).catch(()=>{});return serial;}
async function update(tabId,status){const {states={}}=await chrome.storage.local.get('states');states[tabId]={status,at:Date.now()};await chrome.storage.local.set({states});}
async function publish(){
 const {config,states={}}=await chrome.storage.local.get(['config','states']);if(!config)return;
 const tabs=await chrome.tabs.query({url:'https://gemini.google.com/*'});
 const values=tabs.map(t=>states[t.id]&&Date.now()-states[t.id].at<60000?states[t.id].status:'unknown');
 const status=values.includes('working')?'working':values.includes('unknown')?'unknown':values.length?'idle':'offline';
 try{const r=await fetch(URL_BASE+'/rest/v1/rpc/report_agent_presence',{method:'POST',headers:{apikey:config.publicKey,'Content-Type':'application/json'},body:JSON.stringify({p_token:config.token,p_session:'browser',p_status:status,p_event_ms:Date.now()}),signal:AbortSignal.timeout(8000)});await chrome.storage.local.set({last:{status,ok:r.ok,at:Date.now()}});}catch{await chrome.storage.local.set({last:{status,ok:false,at:Date.now()}});}
}
chrome.runtime.onMessage.addListener((m,s,reply)=>{
 if(m.type==='chat-task')return onChatTask(m,s,reply);
 if(m.type==='status'&&s.tab&&s.url?.startsWith('https://gemini.google.com/')&&['working','idle','unknown'].includes(m.status)){queue(async()=>{await update(s.tab.id,m.status);await publish();});}
 if(m.type==='bind'&&!s.tab&&s.url===chrome.runtime.getURL('popup.html')){
  queue(async()=>{const c=m.config;if(c?.provider!=='gemini-browser'||c.url!==URL_BASE||!/^[a-f0-9]{64}$/.test(c.token)||typeof c.publicKey!=='string')throw Error('Invalid code');await chrome.storage.local.set({config:c,states:{},chatTasks:[]});await publish();reply({ok:true});}).then(()=>reply({ok:false}));return true;
 }
});
chrome.alarms.create('heartbeat',{periodInMinutes:0.5});
chrome.alarms.onAlarm.addListener(()=>queue(async()=>{const tabs=await chrome.tabs.query({url:'https://gemini.google.com/*'});for(const t of tabs){try{const r=await chrome.tabs.sendMessage(t.id,{type:'probe'});if(['working','idle','unknown'].includes(r?.status))await update(t.id,r.status);}catch{await update(t.id,'unknown');}}await publish();await flushTasks();}));
chrome.tabs.onRemoved.addListener(()=>queue(publish));
chrome.tabs.onUpdated.addListener((id,change)=>{if(change.status==='loading')queue(async()=>{await update(id,'unknown');await publish();});});

const digest=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))),n=>n.toString(16).padStart(2,'0')).join('');
async function flushTasks(){
 const {config,chatTasks=[]}=await chrome.storage.local.get(['config','chatTasks']);if(!config)return;
 const remaining=[];
 for(const e of chatTasks){
  try{const r=await fetch(URL_BASE+'/rest/v1/rpc/report_chat_activity',{method:'POST',headers:{apikey:config.publicKey,'Content-Type':'application/json'},body:JSON.stringify({p_token:config.token,p_session:await digest('gemini:'+e.session),p_event:await digest('gemini:'+e.event),p_title:e.title,p_source:await digest('gemini:'+e.source),p_source_label:e.sourceLabel,p_event_ms:e.at}),signal:AbortSignal.timeout(8000)});if(!r.ok)remaining.push(e);await chrome.storage.local.set({lastChat:{ok:r.ok,http:r.status,at:Date.now()}});}catch{remaining.push(e);}
 }
 await chrome.storage.local.set({chatTasks:remaining});
}
function onChatTask(m,s,reply){
 if(m.type!=='chat-task'||!s.tab||!s.url?.startsWith('https://gemini.google.com/'))return;
 if(!['session','event','title','source','sourceLabel'].every(k=>typeof m[k]==='string'&&m[k].length<=300)||!m.title.trim()||!Number.isFinite(m.at)||Math.abs(Date.now()-m.at)>180000)return;
 queue(async()=>{const {config,chatTasks=[]}=await chrome.storage.local.get(['config','chatTasks']);if(!config){reply({ok:false,reason:'not-bound'});return;}chatTasks.push({session:m.session,event:m.event,title:m.title,source:m.source,sourceLabel:m.sourceLabel,at:m.at});await chrome.storage.local.set({chatTasks});reply({ok:true});await flushTasks();});return true;
}

