// Derive a short task topic locally; never serialize the full prompt or response.
globalThis.stopWorkbenchChatTasks?.();
(()=>{
 const provider=location.hostname==='chatgpt.com'?'chatgpt-browser':'gemini-browser';
 let pending=null,disposed=false,inflight=false,reason="waiting-for-send";
 const events={enter:0,sendButton:0,submit:0};let lastInputAt=0,lastTopic='';
 const eventRoot=globalThis.window||document;
 const hasText=e=>!!e&&String(e.matches?.("input,textarea")?e.value:e.textContent??e.value??"").trim()!=="";
 const userCount=()=>document.querySelectorAll('[data-message-author-role="user"],user-query').length;
 const detect=()=>provider==='chatgpt-browser'?detectChatGPTStatus():detectGeminiStatus();
 const editor=()=>typeof globalThis.findGeminiEditor==='function'?globalThis.findGeminiEditor():document.querySelector('#prompt-textarea,rich-textarea [contenteditable="true"],textarea[placeholder],.ql-editor[contenteditable="true"]');
 const raw=e=>String(e?.matches?.('input,textarea')?e.value:e?.textContent??e?.value??'');
 function topicFrom(e){let s=raw(e).replace(/https?:\/\/\S+/gi,' ').replace(/\s+/g,' ').trim();const x=/^(?:#\s*)?(?:新任务|任务)\s*[：:]\s*(.+)$/i.exec(s);s=(x?x[1]:s.replace(/^(?:(?:请你?|麻烦你?|帮我|帮忙|能否|可否|可以|我想要?|我需要|接下来|下面|然后)\s*)+/,'')).split(/(?<=[。！？!?；;])\s*/)[0].replace(/^[，,。.!！?？:：;；\s]+|[，,。.!！?？:：;；\s]+$/g,'').trim();if(!s||/^(继续|好的?|好|可以|行|嗯+|收到|明白|开始|执行|接着|下一步|再来|重试|完成了?|已完成|谢谢|ok|okay|yes|go|continue|.+已(?:连接|完成|授权|处理|发送))$/i.test(s))return '';return [...s].slice(0,60).join('');}
 const explicitFrom=e=>/^(?:#\s*)?(?:新任务|任务)\s*[：:]|^(?:我们)?(?:换个话题|切换话题|开始新任务)\b/i.test(raw(e).trim());
 const topicKey=()=>`workbench-topic:${location.pathname.match(/\/app\/([^/]+)/)?.[1]||'new'}`;
 function readTitle(){
  const clean=value=>(value||'').trim().replace(/^ChatGPT\s*[-–|]\s*/i,'').replace(/\s*[-–|]\s*(ChatGPT|Google Gemini|Gemini)\s*$/i,'').slice(0,300);
  const usable=value=>value&&!/^(ChatGPT|Gemini|Google Gemini|新对话|New chat|跳转到内容|跳至内容|Skip to content)$/i.test(value);
  const pageTitle=clean(document.title);if(usable(pageTitle))return pageTitle;
  const same=[...document.querySelectorAll('a[href]')].find(a=>{try{const raw=a.getAttribute('href')||'';const url=new URL(a.href);return !raw.startsWith('#')&&!url.hash&&/\/app\/[^/]+/.test(url.pathname)&&url.pathname===location.pathname;}catch{return false;}});
  const selected=document.querySelector('.conversation.selected .conversation-title,.conversation-container.selected .conversation-title,[aria-current="page"] .conversation-title,[aria-selected="true"] .conversation-title');
  const title=clean(same?.querySelector('.conversation-title')?.textContent||same?.textContent||selected?.textContent);return usable(title)?title:'';
 }
 function intent(){const e=editor();if(!e||(!hasText(e)&&Date.now()-lastInputAt>2000)){reason='send-without-draft';return;}if(pending&&Date.now()-pending.at<750)return;const explicit=explicitFrom(e),topic=topicFrom(e);if(!topic){reason='ignored-non-task-message';return;}lastTopic=topic;pending={at:Date.now(),event:crypto.randomUUID(),topic,explicit,confirmed:0,path:location.pathname,userCount:userCount()};reason='send-observed';}
 function key(e){if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&editor()?.contains(e.target)){events.enter++;intent();}}
 function click(e){const b=e.target.closest?.('button,[role="button"]');if(!b)return;const label=[b.getAttribute('aria-label'),b.getAttribute('data-testid'),b.getAttribute('data-test-id'),b.getAttribute('title')].filter(Boolean).join(' ');if(/^(send|发送|提交)|send-button|send message|发送消息|发送提示/i.test(label)){events.sendButton++;intent();}}
 function input(e){if(editor()?.contains(e.target)&&hasText(editor())){lastInputAt=Date.now();lastTopic=topicFrom(editor())||lastTopic;}}
 function submit(e){if(e.target.contains?.(editor())){events.submit++;intent();}}
 const listeners={keydown:key,pointerdown:click,click,input,submit};
 for(const [name,fn] of Object.entries(listeners))eventRoot.addEventListener(name,fn,true);
 const timer=setInterval(()=>{
  if(disposed||!pending||inflight)return;
  if(Date.now()-pending.at>120000){reason="send-expired";pending=null;return;}
  try{
   if(!pending.confirmed&&(detect()==='working'||(userCount()>pending.userCount&&(editor()?.value??editor()?.textContent??'').trim()===''))){pending.confirmed=Date.now();reason='send-confirmed';}
   if(!pending.confirmed||Date.now()-pending.confirmed<4000)return;
   const match=location.pathname.match(provider==='chatgpt-browser'?/\/c\/([^/]+)/:/\/app\/([^/]+)/);if(!match){reason='waiting-for-chat-id';return;}
   const platformTitle=readTitle();if(!pending.explicit&&!platformTitle){reason='waiting-for-title';return;}
   const title=`Gemini｜${pending.explicit?pending.topic:platformTitle}`.slice(0,300);
   const group=location.pathname.match(/\/g\/(g-p-[^/]+)/)?.[1];
   const groupLink=group?[...document.querySelectorAll('a[href]')].find(a=>a.href.includes('/g/'+group)&&!a.href.includes('/c/')):null;
   const source=group?'project:'+group:'chat:'+match[1];
   const sourceLabel=(groupLink?.textContent?.trim()||title).slice(0,300);
   const event={type:'chat-task',session:match[1]+(pending.explicit?':topic:'+pending.topic:''),event:pending.event,title,source,sourceLabel,at:pending.at};
   inflight=true;reason='uploading';chrome.runtime.sendMessage(event).then(reply=>{if(reply?.ok){sessionStorage.setItem(topicKey(),pending.topic);pending=null;reason='queued';}else reason='worker-not-acknowledged';}).catch(()=>{reason='worker-unavailable';}).finally(()=>{inflight=false;});
  }catch{}
 },500);
 globalThis.workbenchChatTaskDiagnostic=()=>({version:'1.3.0',titleCandidate:readTitle(),topicCandidate:lastTopic,events:{...events},draftPresent:hasText(editor()),reason,pending:!!pending,confirmed:!!pending?.confirmed,editorFound:!!editor(),userMessageCount:userCount()});
 globalThis.stopWorkbenchChatTasks=()=>{disposed=true;clearInterval(timer);for(const [name,fn] of Object.entries(listeners))eventRoot.removeEventListener(name,fn,true);};
})();
