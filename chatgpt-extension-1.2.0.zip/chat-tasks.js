// Derive a short task topic locally; never serialize the full prompt or response.
globalThis.stopWorkbenchChatTasks?.();
(()=>{
 const provider=location.hostname==='chatgpt.com'?'chatgpt-browser':'gemini-browser';
 let pending=null,disposed=false,inflight=false,reason="waiting-for-send";
 const events={enter:0,sendButton:0,submit:0,workingEdge:0,draftSeen:0};let lastInputAt=0,lastDraftAt=0,lastStatus='',lastTopic='';
 const eventRoot=globalThis.window||document;
 const hasText=e=>!!e&&String(e.matches?.("input,textarea")?e.value:e.textContent??e.value??"").trim()!=="";
 const userCount=()=>document.querySelectorAll('[data-message-author-role="user"],user-query').length;
 const detect=()=>provider==='chatgpt-browser'?detectChatGPTStatus():detectGeminiStatus();
 const editor=()=>provider==='chatgpt-browser'&&typeof globalThis.findChatGPTEditor==='function'?globalThis.findChatGPTEditor():document.querySelector('#prompt-textarea,rich-textarea [contenteditable="true"],textarea[placeholder],.ql-editor[contenteditable="true"]');
 const raw=e=>String(e?.matches?.('input,textarea')?e.value:e?.textContent??e?.value??'');
 function topicFrom(e){let s=raw(e).replace(/https?:\/\/\S+/gi,' ').replace(/\s+/g,' ').trim();const x=/^(?:#\s*)?任务\s*[：:]\s*(.+)$/i.exec(s);s=(x?x[1]:s.replace(/^(?:(?:请你?|麻烦你?|帮我|帮忙|能否|可否|可以|我想要?|我需要|接下来|下面|然后)\s*)+/,'')).split(/(?<=[。！？!?；;])\s*/)[0].replace(/^[，,。.!！?？:：;；\s]+|[，,。.!！?？:：;；\s]+$/g,'').trim();if(!s||/^(继续|好的?|好|可以|行|嗯+|收到|明白|开始|执行|接着|下一步|再来|重试|完成了?|已完成|谢谢|ok|okay|yes|go|continue)$/i.test(s))return '';return [...s].slice(0,60).join('');}
 const topicKey=()=>`workbench-topic:${location.pathname.match(/\/c\/([^/]+)/)?.[1]||'new'}`;
 function readTitle(){
  const clean=value=>(value||'').trim().replace(/^ChatGPT\s*[-–|]\s*/i,'').replace(/\s*[-–|]\s*(ChatGPT|Google Gemini|Gemini)\s*$/i,'').slice(0,300);
  const usable=value=>value&&!/^(ChatGPT|Gemini|Google Gemini|新对话|New chat|跳转到内容|跳至内容|Skip to content)$/i.test(value);
  const pageTitle=clean(document.title);if(usable(pageTitle))return pageTitle;
  const same=[...document.querySelectorAll('a[href]')].find(a=>{try{const raw=a.getAttribute('href')||'';const url=new URL(a.href);return !raw.startsWith('#')&&!url.hash&&/\/c\//.test(url.pathname)&&url.pathname===location.pathname;}catch{return false;}});
  const title=clean(same?.textContent);return usable(title)?title:'';
 }
 function intent(){const e=editor();if(!e||(!hasText(e)&&Date.now()-lastInputAt>2000)){reason='send-without-draft';return;}if(pending&&Date.now()-pending.at<750)return;const topic=topicFrom(e)||lastTopic||sessionStorage.getItem(topicKey())||'';if(!topic){reason='waiting-for-topic';return;}lastTopic=topic;pending={at:Date.now(),event:crypto.randomUUID(),topic,confirmed:0,path:location.pathname,userCount:userCount()};reason='send-observed';}
 function key(e){if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&editor()?.contains(e.target)){events.enter++;intent();}}
 function click(e){const b=e.target.closest?.('button,[role="button"]');if(!b)return;const label=[b.getAttribute('aria-label'),b.getAttribute('data-testid'),b.getAttribute('title')].filter(Boolean).join(' ');if(/^(send|发送|提交)|send-button|send message|发送消息|发送提示/i.test(label)){events.sendButton++;intent();}}
 function input(e){if(editor()?.contains(e.target)&&hasText(editor())){lastInputAt=lastDraftAt=Date.now();lastTopic=topicFrom(editor())||lastTopic;}}
 function submit(e){if(e.target.contains?.(editor())){events.submit++;intent();}}
 const listeners={keydown:key,pointerdown:click,click,input,submit};
 for(const [name,fn] of Object.entries(listeners))eventRoot.addEventListener(name,fn,true);
 const timer=setInterval(()=>{
  if(disposed)return;
  const currentEditor=editor(),currentStatus=detect(),now=Date.now();
  if(hasText(currentEditor)){if(now-lastDraftAt>750)events.draftSeen++;lastDraftAt=now;lastTopic=topicFrom(currentEditor)||lastTopic;}
  // ChatGPT occasionally consumes send events before an extension listener can see
  // them. A recently non-empty composer followed by idle -> working is an equally
  // explicit send signal and contains no prompt or response text.
  if(currentStatus==='working'&&lastStatus!=='working'){
   events.workingEdge++;
   if(!pending&&(now-lastDraftAt<10000||now-lastInputAt<10000))intent();
  }
  lastStatus=currentStatus;
  if(!pending||inflight)return;
  if(Date.now()-pending.at>120000){reason="send-expired";pending=null;return;}
  try{
   if(!pending.confirmed&&(currentStatus==='working'||(userCount()>pending.userCount&&(editor()?.value??editor()?.textContent??'').trim()===''))){pending.confirmed=Date.now();reason='send-confirmed';}
   if(!pending.confirmed||Date.now()-pending.confirmed<4000)return;
   const match=location.pathname.match(provider==='chatgpt-browser'?/\/c\/([^/]+)/:/\/app\/([^/]+)/);if(!match){reason='waiting-for-chat-id';return;}
   const title=`ChatGPT｜${pending.topic}`.slice(0,300);
   const group=location.pathname.match(/\/g\/(g-p-[^/]+)/)?.[1];
   const groupLink=group?[...document.querySelectorAll('a[href]')].find(a=>a.href.includes('/g/'+group)&&!a.href.includes('/c/')):null;
   const source=group?'project:'+group:'chat:'+match[1];
   const sourceLabel=(groupLink?.textContent?.trim()||title).slice(0,300);
   const event={type:'chat-task',session:match[1],event:pending.event,title,source,sourceLabel,at:pending.at};
   inflight=true;reason='uploading';chrome.runtime.sendMessage(event).then(reply=>{if(reply?.ok){sessionStorage.setItem(topicKey(),pending.topic);pending=null;reason='queued';}else reason='worker-not-acknowledged';}).catch(()=>{reason='worker-unavailable';}).finally(()=>{inflight=false;});
  }catch{}
 },200);
 globalThis.workbenchChatTaskDiagnostic=()=>({version:'1.2.0',titleCandidate:readTitle(),topicCandidate:lastTopic,events:{...events},draftPresent:hasText(editor()),reason,pending:!!pending,confirmed:!!pending?.confirmed,editorFound:!!editor(),userMessageCount:userCount()});
 globalThis.stopWorkbenchChatTasks=()=>{disposed=true;clearInterval(timer);for(const [name,fn] of Object.entries(listeners))eventRoot.removeEventListener(name,fn,true);};
})();
